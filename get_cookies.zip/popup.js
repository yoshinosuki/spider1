document.addEventListener('DOMContentLoaded', function() {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      var tab = tabs[0];
      chrome.runtime.sendMessage({ tabId: tab.id }, function(response) {
        var outputElement = document.getElementById('output');
        outputElement.textContent = JSON.stringify(response, null);
      });
    });
});
