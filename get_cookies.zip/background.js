chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.tabId) {
      chrome.tabs.get(request.tabId, function(tab) {
		// skip urls like "chrome://" to avoid extension error
		if (tab.url?.startsWith("chrome://")){
			return false;
		}
        chrome.cookies.getAll({ url: tab.url }, function(cookies) {
          var localStorage = {};
          var sessionStorage = {};
  
          if (tab.id) {
            chrome.scripting
            .executeScript({
              target : {tabId : tab.id},
              func : ()=> {return JSON.stringify({"localStorage": localStorage, "sessionStorage": sessionStorage});}
            })
            .then(injectionResults => {
                result = JSON.parse(injectionResults[0].result);
                sendResponse({ cookies: cookies, localStorage: result.localStorage, sessionStorage: result.sessionStorage });
              });
          }
        });
      });
    }
  
    return true;
});
